function Footer() {
  return (
    <footer className="site-footer">
      <address>
        <div>г. Астана, ул. Примерная, 1</div>
        <div>Тел.: <a href="tel:+77000000000">+7 700 000 00 00</a></div>
        <div>Email: <a href="mailto:info@agromarket.kz">info@agromarket.kz</a></div>
      </address>
      <p>© 2026 АгроМаркет</p>
    </footer>
  );
}

export default Footer;
